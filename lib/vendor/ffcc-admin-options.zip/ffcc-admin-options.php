<?php /*

**************************************************************************

Plugin Name:  Enable FFCC Theme Options
Description:  Duh.
Version:      0.000001
Author:       Firefly
Author URI:   http://www.fireflycompany.com/

**************************************************************************/

if( function_exists('acf_add_options_page') ) {
	acf_add_options_page(array(
		'page_title' => 'Theme Options'
	));
}