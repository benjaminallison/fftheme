<div class="tm-thumb">
    <a href="<?php echo $link; ?>" title="<?php the_title_attribute(); ?>" target="<?php echo $target; ?>">
        <span class="tm-thumb-image">
            <?php if(has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('tm-featured-image'); ?>
            <?php endif; ?>
        </span> 
        <h3 class="tm-thumb-heading"><?php TMCore::get_page_thumb_heading(); ?></h3>
        <span class="tm-thumb-links">
            <span><?php _e('View Details', 'firefly'); ?></span>
        </span> 
    </a>
</div>