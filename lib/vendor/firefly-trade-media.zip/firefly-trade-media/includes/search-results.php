<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-search-results">

    <?php TMCore::get_search_thumbs();?>

</div>

<?php TMCore::get_footer(); ?>