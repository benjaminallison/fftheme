<div class="wrap">
    
    <h2><?php _e('Trade &amp; Media Settings', 'firefly') ?></h2>
    
    <form action="<?php echo admin_url('/options-general.php?page=tm-settings'); ?>" method="post">
    
        <h3><?php _e('General', 'firefly'); ?></h3>
        
        <table class="form-table">
            <tr>
                <th><?php _e('Index Title', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[index_title]" type="text" value="<?php echo $settings['index_title']; ?>" />
                    <span class="description"><?php _e('A default title for the Trade & Media index.', 'firefly'); ?></span>
                </td>
            </tr>
            <tr>
                <th><?php _e('Index Type', 'firefly'); ?></th>
                <td>
                    <select name="tm_settings[index_type]">
                        <option value="brand" <?php selected($settings['index_type'], 'brand'); ?>><?php _e('Brand', 'firefly'); ?></option>
                        <option value="file" <?php selected($settings['index_type'], 'file'); ?>><?php _e('File List', 'firefly'); ?></option>
                    </select>
                    <span class="description"><?php _e('Are we showing brand level, or using File Lists directly?', 'firefly'); ?></span>
                </td>
            </tr>
            <tr>
                <th><?php _e('Product Type', 'firefly'); ?></th>
                <td>
                    <select name="tm_settings[product_type]">
                        <option value="wine" <?php selected($settings['product_type'], 'wine'); ?>><?php _e('Wine', 'firefly'); ?></option>
                        <option value="other" <?php selected($settings['product_type'], 'other'); ?>><?php _e('Other', 'firefly'); ?></option>
                    </select>
                    <span class="description"><?php _e('What type of product will this trade and media section be for.', 'firefly'); ?></span>
                </td>
            </tr>
            <tr>
                <th><?php _e('Multiple Brands', 'firefly'); ?></th>
                <td>
                    <select name="tm_settings[multi_brand]">
                        <option value="0" <?php selected($settings['multi_brand'], 0); ?>><?php _e('No', 'firefly'); ?></option>
                        <option value="1" <?php selected($settings['multi_brand'], 1); ?>><?php _e('Yes', 'firefly'); ?></option>
                    </select>
                    <span class="description"><?php _e('Enable the frontend of this site to show multiple brands?', 'firefly'); ?></span>
                </td>
            </tr>
            <tr>
                <th><?php _e('URL Slug', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[slug]" type="text" value="<?php echo $settings['slug']; ?>" />
                    <span class="description"><?php _e('The part of the URL that shows in the browser\'s address bar.', 'firefly'); ?></span>
                </td>
            </tr>
            <tr>
                <th><?php _e('Search Form', 'firefly'); ?></th>
                <td>
                    <select name="tm_settings[search_form]">
                        <option value="1" <?php selected($settings['search_form'], 1); ?>><?php _e('Show', 'firefly'); ?></option>
                        <option value="0" <?php selected($settings['search_form'], 0); ?>><?php _e('Hide', 'firefly'); ?></option>
                    </select>
                    <span class="description"><?php _e('Show or hide the frontend search form?', 'firefly'); ?></span>
                </td>
            </tr>
        </table>
    
        <h3><?php _e('Wine Information Columns', 'firefly'); ?></h3>
        
        <?php $wine_info = $settings['wine_info']; ?>
        
        <table class="form-table">
            <tr>
                <th><?php _e('Wine', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][wine][label]" type="text" value="<?php echo $wine_info['wine']['label']; ?>" />
                    <select name="tm_settings[wine_info][wine][enabled]">
                        <option value="1" <?php selected($wine_info['wine']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['wine']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php _e('Vineyard', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][vineyard][label]" type="text" value="<?php echo $wine_info['vineyard']['label']; ?>" />
                    <select name="tm_settings[wine_info][vineyard][enabled]">
                        <option value="1" <?php selected($wine_info['vineyard']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['vineyard']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php _e('Bottle Shots', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][bottle_shots][label]" type="text" value="<?php echo $wine_info['bottle_shots']['label']; ?>" />
                    <select name="tm_settings[wine_info][bottle_shots][enabled]">
                        <option value="1" <?php selected($wine_info['bottle_shots']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['bottle_shots']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php _e('Wine Labels', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][wine_labels][label]" type="text" value="<?php echo $wine_info['wine_labels']['label']; ?>" />
                    <select name="tm_settings[wine_info][wine_labels][enabled]">
                        <option value="1" <?php selected($wine_info['wine_labels']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['wine_labels']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php _e('Tech Sheets', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][tech_sheets][label]" type="text" value="<?php echo $wine_info['tech_sheets']['label']; ?>" />
                    <select name="tm_settings[wine_info][tech_sheets][enabled]">
                        <option value="1" <?php selected($wine_info['tech_sheets']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['tech_sheets']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php _e('Shelf Talkers', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][shelf_talkers][label]" type="text" value="<?php echo $wine_info['shelf_talkers']['label']; ?>" />
                    <select name="tm_settings[wine_info][shelf_talkers][enabled]">
                        <option value="1" <?php selected($wine_info['shelf_talkers']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['shelf_talkers']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php _e('Videos', 'firefly'); ?></th>
                <td>
                    <input name="tm_settings[wine_info][videos][label]" type="text" value="<?php echo $wine_info['videos']['label']; ?>" />
                    <select name="tm_settings[wine_info][videos][enabled]">
                        <option value="1" <?php selected($wine_info['videos']['enabled'], 1); ?>><?php _e('Enabled', 'firefly'); ?></option>
                        <option value="0" <?php selected($wine_info['videos']['enabled'], 0); ?>><?php _e('Disabled', 'firefly'); ?></option>
                    </select>
                </td>
            </tr>
        </table>
    
        <h3><?php _e('Advanced Custom Fields', 'firefly'); ?></h3>
        
        <table class="form-table">
            <tr>
                <th><?php _e('Hide UI', 'firefly'); ?></th>
                <td>
                    <select name="tm_settings[hide_acf_ui]">
                        <option value="0" <?php selected($settings['hide_acf_ui'], 0); ?>><?php _e('No', 'firefly'); ?></option>
                        <option value="1" <?php selected($settings['hide_acf_ui'], 1); ?>><?php _e('Yes', 'firefly'); ?></option>
                    </select>
                    <span class="description"><?php _e('Hide the Advanced Custom Fields UI?', 'firefly'); ?></span>
                </td>
            </tr>
        </table>
    
        <p class="submit">
            <input type="submit" name="update" class="button-primary" value="<?php _e('Save Settings', 'firefly'); ?>" />
            <?php wp_nonce_field('tm-settings', 'tm-settings-nonce'); ?>
        </p>
    
    </form>

</div>