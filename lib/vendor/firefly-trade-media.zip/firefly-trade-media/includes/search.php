<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-search">

    <?php TMCore::get_brand_thumbs();?>
    
</div>

<?php TMCore::get_footer(); ?>