<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-search">

    <?php
    	if ( TMSettings::get('index_type') == "brand" ) {
		    TMCore::get_brand_thumbs();
    	} else if ( TMSettings::get('index_type') == "file" ) {
    	    TMCore::get_file_list_thumbs();
    	}
    ?>
    
</div>

<?php TMCore::get_footer(); ?>