<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-wine-info">

    <select class="tm-wine-info-filter">
        <option value=""><?php _e('View all wines', 'firefly'); ?></option>
    </select>
    
    <table class="tm-wine-info-table" cellpadding="0" cellspacing="0">
        <tr class="tm-wine-info-headings">
        
            <?php $columns = TMSettings::get('wine_info'); ?>
        
            <?php if($columns['wine']['enabled']) : ?>
            <th class="tm-wine-info-wine-heading"><?php echo $columns['wine']['label']; ?></th>
            <?php endif; ?>
            
            <?php if($columns['vineyard']['enabled']) : ?>
            <th class="tm-wine-info-vineyard-heading"><?php echo $columns['vineyard']['label']; ?></th>
            <?php endif; ?>
            
            <?php if($columns['bottle_shots']['enabled']) : ?>
            <th class="tm-wine-info-shots-heading"><?php echo $columns['bottle_shots']['label']; ?></th>
            <?php endif; ?>
            
            <?php if($columns['wine_labels']['enabled']) : ?>
            <th class="tm-wine-info-labels-heading"><?php echo $columns['wine_labels']['label']; ?></th>
            <?php endif; ?>
            
            <?php if($columns['tech_sheets']['enabled']) : ?>
            <th class="tm-wine-info-sheets-heading"><?php echo $columns['tech_sheets']['label']; ?></th>
            <?php endif; ?>
            
            <?php if($columns['shelf_talkers']['enabled']) : ?>
            <th class="tm-wine-info-sheets-heading"><?php echo $columns['shelf_talkers']['label']; ?></th>
            <?php endif; ?>
            
            <?php if($columns['videos']['enabled']) : ?>
            <th class="tm-wine-info-videos-heading"><?php echo $columns['videos']['label']; ?></th>
            <?php endif; ?>
        </tr>
        <?php TMWineInfo::get_html(); ?>
    </table>
    
</div>

<?php TMCore::get_footer(); ?>