    </div><!-- .tm-content -->
</div><!-- .tm-content-wrap -->

<?php get_footer(); ?>