<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-gallery">
    
    <?php TMGallery::get_html(); ?>
    
</div>

<?php TMCore::get_footer(); ?>