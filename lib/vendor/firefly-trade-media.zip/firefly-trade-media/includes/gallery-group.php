<?php if(count($groups) > 0) : ?>
<h3 class="tm-gallery-group-title"><?php echo $group['title']; ?></h3>
<?php endif; ?>

<div class="tm-thumbs tm-clearfix">
<?php 

if($group['type'] == 'photos') {
    TMGallery::get_photos_html($group);
}
if($group['type'] == 'videos') {
    TMGallery::get_videos_html($group);
}

?>
</div>