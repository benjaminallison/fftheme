<div class="tm-thumb">
    <a href="#<?php echo $bio_id; ?>" class="tm-bios-fancybox">
    
        <span class="tm-thumb-image">
            <img src="<?php echo $bio['photo']['sizes']['tm-featured-image']; ?>" alt="<?php echo esc_attr($bio['name']); ?>" />
        </span> 
        
        <h3 class="tm-thumb-heading"><?php echo $bio['name']; ?></h3>
        
        <?php if(!empty($bio['title'])) : ?>
        <h4 class="tm-thumb-subheading"><?php echo $bio['title']; ?></h4>
        <?php endif; ?>
        
        <span class="tm-thumb-links">
            <span><?php _e('View Details', 'firefly'); ?></span>
        </span> 
        
    </a>
    
    <div id="<?php echo $bio_id; ?>" class="tm-bio-lightbox">
    
        <div class="tm-bio-lightbox-left">
        
            <img class="tm-bio-lightbox-image" src="<?php echo $bio['photo']['sizes']['tm-featured-image']; ?>" />
            
            <?php if(!empty($bio['pdf'])) : ?>
            <a class="tm-bio-lightbox-pdf" href="<?php echo $bio['pdf']; ?>" target="_blank"><?php _e('Download PDF', 'firefly'); ?></a>
            <?php endif; ?>
            
        </div> 
        
        <div class="tm-bio-lightbox-right">
        
            <h3 class="tm-bio-lightbox-heading"><?php echo $bio['name']; ?></h3>
            
            <?php if(!empty($bio['title'])) : ?>
            <h4 class="tm-bio-lightbox-subheading"><?php echo $bio['title']; ?></h4>
            <?php endif; ?>
            
            <div class="tm-bio-lightbox-text">
                <?php echo $bio['text']; ?>
            </div>
            
        </div> 
        
    </div>
</div>