<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-file-list">
    
    <?php TMFileList::get_html(); ?>
    
</div>

<?php TMCore::get_footer(); ?>