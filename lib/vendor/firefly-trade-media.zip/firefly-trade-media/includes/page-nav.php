<?php if(isset($post_parent)) : ?>
<div class="tm-breadcrumb tm-clearfix">
    <a href="<?php echo get_post_type_archive_link(TM_POST_TYPE); ?>"><?php _e('Trade &amp; Media', 'firefly'); ?></a>
    <span class="tm-breadcrumb-sep"> &rsaquo; </span>
    <a href="<?php echo get_permalink($post_parent); ?>"><?php echo get_the_title($post_parent); ?></a>
</div>
<?php endif; ?>
<div class="tm-page-nav tm-clearfix">
    <ul>
        <?php foreach($pages as $page) : ?>
        <li><a href="<?php echo get_permalink($page); ?>"><?php echo get_the_title($page); ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>