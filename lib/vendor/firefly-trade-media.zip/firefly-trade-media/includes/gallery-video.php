<div class="tm-thumb tm-gallery-item tm-gallery-video">
    <span class="tm-thumb-image">
    
        <a href="#<?php echo md5($video['url']); ?>" class="tm-fancybox"></a>
        
        <img src="<?php echo $video['thumbnail']['sizes']['tm-featured-image']; ?>" />
        
        <div id="<?php echo md5($video['url']); ?>" class="tm-video-lightbox tm-gallery-video-lightbox">
            <?php global $wp_embed; echo $wp_embed->autoembed($video['url']); ?>
        </div>
        
    </span>
</div>