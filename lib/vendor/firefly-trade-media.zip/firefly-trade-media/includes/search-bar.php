<div class="tm-search-bar">

    <form method="GET" action="<?php echo home_url('/trade-and-media/'); ?>">
        
        <?php if(TMSettings::get('multi_brand')) : ?>
        
            <?php  if(is_post_type_archive(TM_POST_TYPE)) : ?>
            <select class="tm-search-bar-brand" name="brand">
                <option value=""><?php _e('All Brands', 'firefly'); ?></option>
                <?php TMCore::get_brand_search_options(); ?>
            </select>
            <?php else: ?>
            <input type="hidden" name="brand" value="<?php echo TMCore::get_brand_id(); ?>" />
            <?php endif; ?>
        
        <?php endif; ?>
        
        <input class="tm-search-bar-text" name="search" type="text" value="<?php echo @$_REQUEST['search']; ?>" />
        
        <input class="tm-search-bar-submit" type="submit" value="<?php _e('Search', 'firefly'); ?>" />
        
    </form>
    
</div>