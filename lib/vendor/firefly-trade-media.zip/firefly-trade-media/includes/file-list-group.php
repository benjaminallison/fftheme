<?php if(count($groups) > 0) : ?>
<h3 class="tm-file-group-title"><?php echo $group['title']; ?></h3>
<?php endif; ?>
<ul>
<?php foreach($group['files'] as $file) : ?>
    <?php
    
    $title       = !empty($file['title']) ? $file['title'] : $file['file']['title'];
    $path        = str_replace(site_url('/'), ABSPATH, $file['file']['url']);
    $description = !empty($file['description']) ? ' &mdash; ' . $file['description'] : '';
    
    ?>
    <li>
        <a href="<?php echo $file['file']['url']; ?>" target="_blank"><?php echo $title; ?></a>
        <?php echo '(' . TMFileList::filesize($path) . ')' . $description; ?>
    </li>
<?php endforeach; ?>
</ul>