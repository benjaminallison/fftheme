<?php if(count($groups) > 0) : ?>
<div class="tm-file-group">
	<h3 class="tm-file-group-title"><?php echo $group['title']; ?></h3>

		<?php if($group['file_list_thumb']) : ?>
			<div class="tm-file-list-thumb">
				<?php if($group['file_list_thumb']['sizes']['medium']) : ?>
					<img src="<?php echo $group['file_list_thumb']['sizes']['medium']; ?>" />
				<?php endif; ?>
			</div>
		<?php endif; ?>
<?php endif; ?>
	<ul>
	<?php foreach($group['files'] as $file) : ?>
		<?php
		
		$title       = !empty($file['title']) ? $file['title'] : $file['file']['title'];
		$path        = str_replace(site_url('/'), ABSPATH, $file['file']['url']);
		$description = !empty($file['description']) ? ' &mdash; ' . $file['description'] : '';
		
		?>
		<li>
			<a href="<?php echo $file['file']['url']; ?>" target="_blank"><?php echo $title; ?></a>
			<?php echo '(' . TMFileList::filesize($path) . ')' . $description; ?>
		</li>
	<?php endforeach; ?>
	<?php if ( $group['sub-group'] ) : ?>
	<?php foreach($group['sub-group'] as $subgroup) : ?>
		<li>
			<h4 class="tm-file-sub-group-title"><?php echo $subgroup['sub-group-title']; ?></h4>
			<ul>
			<?php foreach($subgroup['sub-group-files'] as $file) : ?>
				<?php
					$title       = !empty($file['sub-group-file-title']) ? $file['sub-group-file-title'] : $file['sub-group-file']['title'];
					$path        = str_replace(site_url('/'), ABSPATH, $file['sub-group-file']['url']);
					$description = !empty($file['sub-group-file-description']) ? ' &mdash; ' . $file['sub-group-file-description'] : '';
				?>
				<li>
					<a href="<?php echo $file['sub-group-file']['url']; ?>" target="_blank"><?php echo $title; ?></a>
					<?php echo '(' . TMFileList::filesize($path) . ')' . $description; ?>
				</li>
			<?php endforeach; ?>
			</ul>
		</li>
	<?php endforeach; ?>
	<?php endif; ?>
	</ul>
</div>