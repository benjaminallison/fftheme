<tr class="tm-wine-info-group" data-group="<?php echo $group['title']; ?>">
    <th colspan="7"><?php echo $group['title']; ?></th>
</tr>

<?php foreach($group['wines'] as $wine) : ?>

    <?php 
    
    $filter         = trim(str_replace(range(0,9), '', $wine['name'])); 
    $bottle_urls    = TMCore::get_photo_download_urls($wine['bottle_shot']);
    $label_urls     = TMCore::get_photo_download_urls($wine['label']);
    
    ?>

    <tr class="tm-wine-info-data" data-group="<?php echo $group['title']; ?>" data-filter="<?php echo $filter; ?>">
    
        <?php if($columns['wine']['enabled']) : ?>
        <td class="tm-wine-info-name"><?php echo $wine['name']; ?></td>
        <?php endif; ?>
        
        <?php if($columns['vineyard']['enabled']) : ?>
        <td class="tm-wine-info-vineyard"><?php echo $wine['vineyard']; ?></td>
        <?php endif; ?>
        
        <?php if($columns['bottle_shots']['enabled']) : ?>
        <td class="tm-wine-info-shot">
            <?php if($wine['bottle_shot']) : ?>
            
                <?php if($bottle_urls['lowres']) : ?>
                <a href="<?php echo $bottle_urls['lowres']; ?>" target="_blank"><?php _e('Low-Res', 'firefly'); ?></a>
                <?php endif; ?>
                
                <?php if($bottle_urls['hires']) : ?>
                <span> / </span>
                <a href="<?php echo $bottle_urls['hires']; ?>" target="_blank"><?php _e('Hi-Res', 'firefly'); ?></a>
                <?php endif; ?>
                
            <?php endif; ?>
        </td>
        <?php endif; ?>
        
        <?php if($columns['wine_labels']['enabled']) : ?>
        <td class="tm-wine-info-label">
            <?php if($wine['label']) : ?>
            
                <?php if($label_urls['lowres']) : ?>
                <a href="<?php echo $label_urls['lowres']; ?>" target="_blank"><?php _e('Low-Res', 'firefly'); ?></a>
                <?php endif; ?>
            
                <?php if($label_urls['hires']) : ?>
                <span> / </span>
                <a href="<?php echo $label_urls['hires']; ?>" target="_blank"><?php _e('Hi-Res', 'firefly'); ?></a>
                <?php endif; ?>
                
            <?php endif; ?>
        </td>
        <?php endif; ?>
        
        <?php if($columns['tech_sheets']['enabled']) : ?>
        <td class="tm-wine-info-sheet">
            <?php if($wine['tech_sheet']) : ?>
            <a href="<?php echo $wine['tech_sheet']; ?>" target="_blank"><?php _e('Download', 'firefly'); ?></a>
            <?php endif; ?>
        </td>
        <?php endif; ?>
        
        <?php if($columns['shelf_talkers']['enabled']) : ?>
        <td class="tm-wine-info-shelf-talker">
            <?php if($wine['shelf_talker']) : ?>
            <a href="<?php echo $wine['shelf_talker']; ?>" target="_blank"><?php _e('Download', 'firefly'); ?></a>
            <?php endif; ?>
        </td>
        <?php endif; ?>
        
        <?php if($columns['videos']['enabled']) : ?>
        <td class="tm-wine-info-video">
            <?php if($wine['video']) : ?>
            <div id="<?php echo md5($wine['video']); ?>" class="tm-video-lightbox tm-wine-info-video-lightbox">
                <?php global $wp_embed; echo $wp_embed->autoembed($wine['video']); ?>
            </div>
            <a class="tm-fancybox" href="#<?php echo md5($wine['video']); ?>"><?php _e('View', 'firefly'); ?></a>
            <?php endif; ?>
        </td>
        <?php endif; ?>
    </tr>
    
<?php endforeach; ?>