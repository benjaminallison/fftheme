<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-brand">
    
    <?php TMCore::get_page_thumbs();?>

</div>

<?php TMCore::get_footer(); ?>