<div class="tm-thumb tm-gallery-item tm-gallery-photo">
    <span class="tm-thumb-image">
        <a href="<?php echo $photo['sizes']['large']; ?>" class="tm-fancybox" rel="<?php echo $group['title']; ?>">
            <img src="<?php echo $photo['sizes']['tm-featured-image']; ?>" />
        </a>
    </span>
    <span class="tm-thumb-links">
        <span><?php _e('Download:', 'firefly'); ?></span>

        <?php if($urls['lowres']) : ?>
        <a href="<?php echo $urls['lowres']; ?>"><?php _e('Low-Res', 'firefly'); ?></a>
        <?php endif; ?>
        
        <?php if($urls['hires']) : ?>
        <span> / </span>
        <a href="<?php echo $urls['hires']; ?>"><?php _e('Hi-Res', 'firefly'); ?></a>
        <?php endif; ?>
        
        <?php if(isset($urls['file'])) : ?>
        <span> / </span>
        <a href="<?php echo $urls['file']; ?>"><?php _e('File', 'firefly'); ?></a>
        <?php endif; ?>
    </span> 
</div>