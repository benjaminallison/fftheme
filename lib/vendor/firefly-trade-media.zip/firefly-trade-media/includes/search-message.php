<?php if($query->have_posts()) : ?>

<div class="tm-search-message">

    <p><?php echo $message; ?> <a href="<?php echo home_url('/trade-and-media/'); ?>"><?php _e('Clear Search', 'firefly'); ?></a></p>
    
</div>

<?php else : ?>

<div class="tm-search-message tm-no-results">

    <p><?php _e('Sorry, no results were found. Please try another search.', 'firefly'); ?></p>
    
</div>

<?php endif; ?>