<?php TMCore::get_header(); ?>

<?php TMCore::get_page_heading(); ?>

<div class="tm-standard-page">
    
    <?php echo get_field('standard_page'); ?>
    
</div>

<?php TMCore::get_footer(); ?>