<?php
/**
 * Plugin Name: FireFly Trade and Media
 * Plugin URI: http://www.fireflycompany.com/
 * Description: Adds a trade and media section to any WordPress website.
 * Version: 1.4.2
 * Author: FireFly Creative Co.
 * Author URI: http://www.fireflycompany.com/
 * Copyright: (c) 2014 FireFly Creative Co.
 * Text Domain: firefly
 */
define('TM_PLUGIN_VERSION', '1.4.2');
define('TM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TM_PLUGIN_URL', plugins_url('/', __FILE__));
define('TM_POST_TYPE', 'trade-and-media');

/* Classes */
require_once TM_PLUGIN_DIR . 'classes/TMBios.php';
require_once TM_PLUGIN_DIR . 'classes/TMCore.php';
require_once TM_PLUGIN_DIR . 'classes/TMFields.php';
require_once TM_PLUGIN_DIR . 'classes/TMFileList.php';
require_once TM_PLUGIN_DIR . 'classes/TMGallery.php';
require_once TM_PLUGIN_DIR . 'classes/TMSettings.php';
require_once TM_PLUGIN_DIR . 'classes/TMWineInfo.php';

/* Updater */
require_once TM_PLUGIN_DIR . 'wp-updates-plugin.php';
new WPUpdatesPluginUpdater_717('http://wp-updates.com/api/2/plugin', plugin_basename(__FILE__));

/* Pre Init */
TMCore::pre_init();

/* Plugin Activation */
register_activation_hook(__FILE__,                      'TMCore::activate');

/* Actions */
add_action('init',                                      'TMFields::init');
add_action('plugins_loaded',                            'TMCore::load_plugin_textdomain');
add_action('init',                                      'TMCore::init');
add_action('init',                                      'TMCore::register_post_type');
add_action('wp_enqueue_scripts',                        'TMCore::enqueue_styles');
add_action('wp_enqueue_scripts',                        'TMCore::enqueue_scripts');

/* Admin Actions */
add_action('init',                                      'TMSettings::save', 1);
add_action('admin_menu',                                'TMSettings::admin_menu');
add_action('admin_notices',                             'TMCore::admin_notices');
add_action('admin_enqueue_scripts',                     'TMCore::admin_enqueue_styles');
add_action('save_post_' . TM_POST_TYPE,                 'TMCore::save_post', 999);

/* Filters */
add_filter('template_include',                          'TMCore::template_include', 999);

/* Admin Filters */
add_filter('acf/load_field/key=field_541364dc800ce',    'TMFields::load_section_type');
add_filter('acf/load_field/key=field_54139d51131e2',    'TMFields::load_wines');
add_filter('acf/load_field/key=field_54139d51131e4',    'TMFields::load_wine_name');
add_filter('acf/load_field/key=field_5413a0fdad819',    'TMFields::load_wine_vineyard');
add_filter('acf/load_field/key=field_5413a10fad81a',    'TMFields::load_wine_bottle_shots');
add_filter('acf/load_field/key=field_5413a1b42b2ca',    'TMFields::load_wine_labels');
add_filter('acf/load_field/key=field_5413a1d02b2cb',    'TMFields::load_wine_tech_sheets');
add_filter('acf/load_field/key=field_543c1a52000fe',    'TMFields::load_wine_shelf_talkers');
add_filter('acf/load_field/key=field_5413a1e42b2cc',    'TMFields::load_wine_videos');