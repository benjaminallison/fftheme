(function($){
    
    TMPlugin = {
        
        init: function()
        {
            TMPlugin._initFancybox();
        },
        
        _initFancybox: function()
        {
            $('.tm-fancybox').fancybox({
                autoSize: false
            });
            
            $('.tm-bios-fancybox').fancybox();
        }
    };
    
    $(TMPlugin.init);
    
})(jQuery);