(function($){
    
    TMWineInfo = {
        
        init: function()
        {
            TMWineInfo._bindEvents();
            TMWineInfo._initFilter();
        },
        
        _bindEvents: function()
        {
            $('.tm-wine-info-filter').on('change', TMWineInfo._filterChange);
        },
        
        _initFilter: function()
        {
            var filter  = $('.tm-wine-info-filter'),
                rows    = $('.tm-wine-info-data'),
                i       = 0,
                name    = '',
                names   = [];
            
            for(i = 0; i < rows.length; i++) {
                
                name = $(rows[i]).data('filter');
                
                if($.inArray(name, names) < 0) {
                    names.push(name);
                    filter.append('<option value="' + name + '">' + name + '</option>');
                }
            }
        },
        
        _filterChange: function()
        {
            var groups  = $('.tm-wine-info-group'),
                group   = null,
                rows    = $('.tm-wine-info-data'),
                row     = null,
                val     = $(this).val(),
                i       = 0,
                visible = null;
                
            groups.css('display', 'table-row');
            rows.css('display', 'table-row');
                
            if(val != '') {
                
                for(i = 0; i < rows.length; i++) {
                
                    row = $(rows[i]);
                
                    if(val != row.data('filter')) {
                        row.css('display', 'none');
                    }
                }
                
                for(i = 0; i < groups.length; i++) {
                    
                    group   = $(groups[i]);
                    visible = $('.tm-wine-info-data[data-group="' + group.data('group') + '"]:visible');
                    
                    if(visible.length === 0) {
                        group.css('display', 'none');
                    }
                }
            }
        }
    };
    
    $(TMWineInfo.init);
    
})(jQuery);