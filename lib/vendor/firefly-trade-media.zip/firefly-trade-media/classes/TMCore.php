<?php

/**
 * Main trade and media class.
 *
 * @class TMCore
 */
final class TMCore {

	/**
     * @method pre_init
     */	 
    static public function pre_init() 
    {
        if(TMSettings::get('hide_acf_ui')) {
            define('ACF_LITE', true);
        }
        if(isset($_REQUEST['tm-download'])) {
            self::download();
        }
    }

	/**
     * @method activate
     */	 
    static public function activate() 
    {
        setcookie('TM_ACTIVATING', 1);
    }

	/**
     * @method download
     */	 
    static public function download() 
    {
        if(isset($_REQUEST['tm-download'])) {

            // Build the file path.
            $path = trailingslashit(WP_CONTENT_DIR) . urldecode($_REQUEST['tm-download']);

            // Make sure it exists. 
            if(file_exists($path)) {
                
                // Get the path info.
                $pathinfo = pathinfo($path);
                
                // Make sure someone isn't trying to download files outside of wp-content.
                if(basename($pathinfo['dirname']) == '..') {
                    return;
                }
                
                // Download the file.
                if(isset($_REQUEST['type'])) {
                    header('Content-Type: ' . urldecode($_REQUEST['type']));
                }
                else {
                    header('Content-Type: application/octet-stream');
                }
                
                header('Pragma: public');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Content-Transfer-Encoding: Binary'); 
                header('Content-disposition: attachment; filename="' . basename($path) . '"'); 
                
                readfile($path);
            }
        }
    }

	/**
     * @method get_download_url
     */	 
    static public function get_download_url($url, $mime_type) 
    {
        $parts = explode('/wp-content/', $url);
        
        if(isset($parts[1])) {
            return home_url('/?tm-download=' . $parts[1] . '&type=' . $mime_type);
        }
        else {
            return $url;
        }
    }

	/**
     * @method get_photo_download_urls
     */	 
    static public function get_photo_download_urls($photo) 
    {
        $urls = array(
            'hires'  => null,
            'lowres' => null
        );
            
        if(!empty($photo)) {
        
            $mime_type = get_post_mime_type($photo['ID']);
        
            if(isset($photo['sizes']['large']) && $photo['sizes']['large'] != $photo['url']) {
                $urls['hires'] = self::get_download_url($photo['url'], $mime_type);
                $urls['lowres'] = self::get_download_url($photo['sizes']['large'], $mime_type);
            }
            else {
                $urls['lowres'] = self::get_download_url($photo['url'], $mime_type);
            }
        }
        
        return $urls;
    }

	/**
     * @method init
     */	 
    static public function init() 
    {
        add_image_size('tm-featured-image', 400, 400, true);
    }

	/**
     * @method load_plugin_textdomain
     */	 
    static public function load_plugin_textdomain() 
    {
        load_plugin_textdomain('firefly', false, basename(TM_PLUGIN_DIR) . '/lang/');
    }

	/**
     * @method register_post_type
     */	 
    static public function register_post_type() 
    {
        register_post_type(TM_POST_TYPE, array(
            'label'             => __( TM_POST_TYPE, 'firefly' ),
            'labels'            => array(
                'name'               => _x( 'Trade &amp; Media', 'post type general name', 'firefly' ),
                'singular_name'      => _x( 'Trade &amp; Media', 'post type singular name', 'firefly' ),
                'menu_name'          => _x( 'Trade &amp; Media', 'admin menu', 'firefly' ),
                'name_admin_bar'     => _x( 'Trade &amp; Media', 'add new on admin bar', 'firefly' ),
                'add_new'            => _x( 'Add New', 'firefly' ),
                'add_new_item'       => __( 'Add New Section', 'firefly' ),
                'new_item'           => __( 'New Section', 'firefly' ),
                'edit_item'          => __( 'Edit Section', 'firefly' ),
                'view_item'          => __( 'View Section', 'firefly' ),
                'all_items'          => __( 'All Sections', 'firefly' ),
                'search_items'       => __( 'Search Sections', 'firefly' ),
                'parent_item_colon'  => __( 'Parent Section:', 'firefly' ),
                'not_found'          => __( 'No Trade &amp; Media sections found.', 'firefly' ),
                'not_found_in_trash' => __( 'No Trade &amp; Media sections found in Trash.', 'firefly' )
        	),
            'public'            => true,
            'hierarchical'      => true,
            'has_archive'       => true,
            'menu_position'     => 5,
            'capability_type'   => 'page',
            'supports'          => array(
                'title',
                'thumbnail',
                'page-attributes'
            ),
            'rewrite'           => array(
                'slug'              => TMSettings::get('slug')
            )
        ));
        
        TMSettings::flush_rewrite_rules();
    }

	/**
     * @method enqueue_styles
     */	 
    static public function enqueue_styles() 
    {
        wp_enqueue_style('trade-media', TM_PLUGIN_URL . 'css/trade-media.css');
        wp_enqueue_style('jquery-fancybox', TM_PLUGIN_URL . 'css/jquery.fancybox.css');
    }

	/**
     * @method enqueue_styles
     */	 
    static public function enqueue_scripts() 
    {
        wp_enqueue_script('jquery');
        wp_enqueue_script('trade-media', TM_PLUGIN_URL . 'js/trade-media.js', array(), TM_PLUGIN_VERSION, true);
        wp_enqueue_script('jquery-fancybox', TM_PLUGIN_URL . 'js/jquery.fancybox.pack.js', array(), TM_PLUGIN_VERSION, true);
    }

	/**
     * @method admin_enqueue_styles
     */	 
    static public function admin_enqueue_styles() 
    {
        global $post;
        
        if(isset($post) && $post->post_type == TM_POST_TYPE) {
            wp_enqueue_style('trade-media-admin', TM_PLUGIN_URL . 'css/trade-media-admin.css');
        }
    }

	/**
     * @method admin_notices
     */	 
    static public function admin_notices() 
    {
        if(!function_exists('get_field')) {
            
            echo '<div class="error">';
            echo '<p>' . __('The Advanced Custom Fields plugin must be installed and activated for the Trade &amp; Media section to function properly.', 'firefly') . '</p>';
            echo '</div>';
            
        }
    }

	/**
	 * Save the output of a section so it is searchable.
	 *
     * @method save_post
     */	 
    static public function save_post($post_id) 
    {
        global $wpdb;
        
        if(!function_exists('get_field')) {
            return;
        }
        
        $section_type = get_field('section_type');
        
        if(!empty($section_type) && $section_type != 'brand') {
        
            ob_start();
            
            echo $section_type;
        
            if($section_type == 'file-list') {
                TMFileList::get_html($post_id);
            }
            else if($section_type == 'wine-info') {
                TMWineInfo::get_html($post_id);
            }
            else if($section_type == 'gallery') {
                TMGallery::get_html($post_id);
            }
            else if($section_type == 'bios') {
                TMBios::get_html($post_id);
            }
            else if($section_type == 'standard') {
                the_field('standard_page');
            }
            
            $content = strip_tags(ob_get_clean());
        
            $wpdb->update(
                $wpdb->posts, 
                array(
                    'post_content' => $content
                ),
                array(
                    'ID' => $post_id
                )
            );   
        }
    }

	/**
     * @method template_include
     */	 
    static public function template_include($template) 
    {
        global $post;
        
        // No ACF active! 
        if(!function_exists('get_field')) {
            return $template;
        }
        // Show the search view.
        else if(is_post_type_archive(TM_POST_TYPE)) {
        
            if(isset($_REQUEST['search'])) {
                return TM_PLUGIN_DIR . 'includes/search-results.php';
            }
            else {
                return TM_PLUGIN_DIR . 'includes/search.php';
            }
        }
        // No post found.
        else if(!isset($post)) {
            return $template;
        }
        // Show a specific view.
        else if($post->post_type == TM_POST_TYPE) {
        
            $section_type = get_field('section_type');
            
            if($section_type == 'brand') {
                return TM_PLUGIN_DIR . 'includes/brand.php';
            }
            else if($section_type == 'file-list') {
                return TM_PLUGIN_DIR . 'includes/file-list.php';
            }
            else if($section_type == 'wine-info') {
                wp_enqueue_script('wine-info', TM_PLUGIN_URL . 'js/wine-info.js', array(), TM_PLUGIN_VERSION, true);
                return TM_PLUGIN_DIR . 'includes/wine-info.php';
            }
            else if($section_type == 'gallery') {
                return TM_PLUGIN_DIR . 'includes/gallery.php';
            }
            else if($section_type == 'bios') {
                return TM_PLUGIN_DIR . 'includes/bios.php';
            }
            else if($section_type == 'standard') {
                return TM_PLUGIN_DIR . 'includes/standard.php';
            }
            else if($section_type == 'link') {
                header('Location: ' . get_field('link'));
                exit();
            }
        }
        
        return $template;
    }

	/**
     * @method get_header
     */	 
    static public function get_header() 
    {
        include TM_PLUGIN_DIR . 'includes/header.php';
    }

	/**
     * @method get_footer
     */	 
    static public function get_footer() 
    {
        include TM_PLUGIN_DIR . 'includes/footer.php';
    }

	/**
     * @method get_page_nav
     */	 
    static public function get_page_nav() 
    {
        if(TMSettings::get('multi_brand')) {
            self::get_multi_brand_page_nav();
        }
        else {
            self::get_single_brand_page_nav();
        }
    }

	/**
     * @method get_multi_brand_page_nav
     */	 
    static public function get_multi_brand_page_nav() 
    {
        global $post;
        
        if(!is_post_type_archive(TM_POST_TYPE)) {
        
            $post_parent = $post->post_parent === 0 ? $post->ID : $post->post_parent;
        
            $pages = get_children(array(
                'post_parent' => $post_parent,
                'post_type'   => TM_POST_TYPE,
                'order'       => 'ASC',
                'orderby'     => 'menu_order'
            ));
            
            include TM_PLUGIN_DIR . 'includes/page-nav.php';
        }
    }

	/**
     * @method get_single_brand_page_nav
     */	 
    static public function get_single_brand_page_nav() 
    {
        $pages = get_pages(array(
            'post_type'   => TM_POST_TYPE,
            'order'       => 'ASC',
            'sort_column' => 'menu_order'
        ));
        
        include TM_PLUGIN_DIR . 'includes/page-nav.php';
    }

	/**
     * @method get_page_heading
     */	 
    static public function get_page_heading() 
    {
        global $post;
            
        if(is_post_type_archive(TM_POST_TYPE)) {
            echo '<div class="tm-page-head"><h1 class="tm-page-heading">' . __('Trade &amp; Media', 'firefly') . '</h1></div>';
        }
        else {
        
            $post_parent = $post->post_parent === 0 ? $post->ID : $post->post_parent;
            $prefix      = $post->post_parent === 0 ? '' : get_the_title($post->post_parent) . ' &mdash; ';
            $subheading  = get_field('subheading');
            $description = get_field('description');
            
            // Page heading.
            echo '<div class="tm-page-head"><h1 class="tm-page-heading">' . $prefix . get_the_title() . '</h1>';
            
            // Page subheading.
            if(!empty($subheading)) {
                echo '<h2 class="tm-page-subheading">' . $subheading . '</h2>';
            }
            
            // Page description.
            if(!empty($description)) {
                echo '<div class="tm-page-description">' . $description . '</div>';
            }

            echo '</div>';
        }

        self::get_page_nav();
    
        self::get_search_bar();
        
    }

	/**
     * @method get_search_bar
     */	 
    static public function get_search_bar() 
    {
        if(TMSettings::get('search_form')) {
            include TM_PLUGIN_DIR . 'includes/search-bar.php';
        }
    }

	/**
     * @method get_brand_search_options
     */	 
    static public function get_brand_search_options() 
    {
        $query = new WP_Query(array(
            'posts_per_page' => -1,
            'post_type'      => TM_POST_TYPE,
            'post_parent'    => 0,
            'order'          => 'ASC',
            'orderby'        => 'title',
            'meta_key'       => 'section_type',
            'meta_value'     => 'brand'
        ));
        
        if($query->have_posts()) {
        
            while($query->have_posts()) {
            
                $query->the_post();
                
                $selected = selected(@$_REQUEST['brand'], get_the_ID(), false);
                
                echo '<option value="' . get_the_ID() . '" ' . $selected . '>' . get_the_title() . '</option>';
            }
        }
        
        wp_reset_query();
    }

	/**
     * @method get_brand_id
     */	 
    static public function get_brand_id() 
    {
        global $post;
        
        return $post->post_parent === 0 ? $post->ID : $post->post_parent;
    }

	/**
     * @method get_brand_ids
     */	 
    static public function get_brand_ids() 
    {
        $ids = array();
        
        $query = new WP_Query(array(
            'posts_per_page' => -1,
            'post_type'      => TM_POST_TYPE,
            'post_parent'    => 0,
            'order'          => 'ASC',
            'orderby'        => 'title',
            'meta_key'       => 'section_type',
            'meta_value'     => 'brand'
        ));
        
        if($query->have_posts()) {
        
            while($query->have_posts()) {
            
                $query->the_post();
                
                $ids[] = get_the_ID();
            }
        }
        
        wp_reset_query();
        
        return $ids;
    }

	/**
     * @method get_search_thumbs
     */	 
    static public function get_search_thumbs() 
    {
        // Get the current page number.
        $current_page = get_query_var('paged') ? get_query_var('paged') : 1;
        
        // Get the query args.
        $args = array(
            'posts_per_page' => 12,
            'post_type'      => TM_POST_TYPE,
            'order'          => 'ASC',
            'orderby'        => 'title',
            's'              => $_REQUEST['search'],
            'paged'          => $current_page,
            'post__not_in'   => TMCore::get_brand_ids()
        );
        
        // Add a brand to the query args.
        if(isset($_REQUEST['brand'])) {
            $args['post_parent'] = $_REQUEST['brand'];
        }
        
        // Run the query.
        $query = new WP_Query($args);
        
        // Get the search message and loop.
        TMCore::get_search_message($query);
        TMCore::get_page_thumbs_loop($query);
        
        // Build the pagination.
        $total_pages = $query->max_num_pages;
        
        if($total_pages > 1) {
        
            echo '<div class="tm-pagination">';
            
            echo paginate_links(array(
                'base'     => get_pagenum_link(1) . '%_%',
                'format'   => '&paged=%#%',
                'current'  => $current_page,
                'total'    => $total_pages,
                'type'     => 'list'
            ));
            
            echo '</div>';
        }
    }

	/**
     * @method get_search_message
     */	 
    static public function get_search_message($query) 
    {
        if($query->found_posts > 1) {
            $message = sprintf(__('%s results found', 'firefly'), $query->found_posts);
        }
        else {
            $message = __('1 result found', 'firefly');
        }
        
        if(isset($_REQUEST['brand'])) {
        
            if($_REQUEST['brand'] != 0) {
                $message .= ' ' . __('for', 'firefly') . ' ' . get_the_title($_REQUEST['brand']);
            }
            else {
                $message .= ' ' . __('for all brands', 'firefly');
            }
        } 
        
        if(!empty($_REQUEST['search'])) {
            $message .= ' ' . __('with the term', 'firefly') . ' ' . $_REQUEST['search'];
        }
        
        $message .= '.';
        
        include TM_PLUGIN_DIR . 'includes/search-message.php';
    }

	/**
     * @method get_brand_thumbs
     */	 
    static public function get_brand_thumbs() 
    {
        $params = array(
            'posts_per_page' => -1,
            'post_type'      => TM_POST_TYPE,
            'order'          => 'ASC',
            'orderby'        => 'menu_order'
        );
    
        if(TMSettings::get('multi_brand')) {
            $params['orderby']      = 'title';
            $params['post_parent']  = 0;
            $params['meta_key']     = 'section_type';
            $params['meta_value']   = 'brand';
        }
        
        $query = new WP_Query($params);
        
        TMCore::get_page_thumbs_loop($query);
    }

	/**
     * @method get_page_thumbs
     */	 
    static public function get_page_thumbs() 
    {
        global $post;
        
        $query = new WP_Query(array(
            'posts_per_page' => -1,
            'post_type'      => TM_POST_TYPE,
            'post_parent'    => $post->ID,
            'order'          => 'ASC',
            'orderby'        => 'menu_order'
        ));
        
        TMCore::get_page_thumbs_loop($query);
    }

	/**
     * @method get_page_thumbs_loop
     */	 
    static public function get_page_thumbs_loop($query) 
    {
        echo '<div class="tm-thumbs tm-clearfix">';
        
        if($query->have_posts()) {
        
            while($query->have_posts()) {
            
                $query->the_post();
                
                $section_type   = get_field('section_type');
                $link           = $section_type == 'link' ? get_field('link') : get_permalink();
                $target         = $section_type == 'link' ? '_blank' : '_self';
                
                include TM_PLUGIN_DIR . 'includes/page-thumb.php';
            }
        }
        
        echo '</div>';
        
        wp_reset_query();
    }

	/**
     * @method get_page_thumb_heading
     */	 
    static public function get_page_thumb_heading() 
    {
        global $post;
        
        if(isset($_REQUEST['search'])) {
        
            $parent_id = wp_get_post_parent_id($post->ID);
            
            if($parent_id > 0) {
                echo get_the_title($parent_id) . ' &mdash; ';
            }
        }
        
        the_title();
    }
}