<?php

/**
 * @class TMFileList
 */
final class TMFileList {

	/**
     * @method get_html
     */	 
    static public function get_html($post_id = null) 
    {
        $groups = get_field('file_list', $post_id);
        
        foreach($groups as $group) {
        
            include TM_PLUGIN_DIR . 'includes/file-list-group.php';
        }
    }

	/**
     * @method filesize
     */	 
    static public function filesize($path)
    {
        $bytes = filesize($path);
        
        if($bytes >= 1073741824) {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif($bytes >= 1048576) {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif($bytes >= 1024){
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif($bytes > 1) {
            $bytes = $bytes . ' bytes';
        }
        elseif($bytes == 1) {
            $bytes = $bytes . ' byte';
        }
        else {
            $bytes = '0 bytes';
        }
        
        return $bytes;
    }
}