<?php

/**
 * @class TMFields
 */
final class TMFields {

	/**
     * @method init
     */	 
    static public function init() 
    {
        include TM_PLUGIN_DIR . 'includes/custom-fields.php';
    }

	/**
     * @method load_section_type
     */	 
    static public function load_section_type($field) 
    {
        if(!TMSettings::get('multi_brand')) {
            unset($field['choices']['brand']);
        }
        if(TMSettings::get('product_type') != 'wine') {
            unset($field['choices']['wine-info']);
        }
        
        return $field;
    }

	/**
     * @method load_wines
     */	 
    static public function load_wines($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        
        foreach($field['sub_fields'] as $key => $sub_field) {
            
            if($sub_field['name'] == 'name' && !$wine_info['wine']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
            else if($sub_field['name'] == 'vineyard' && !$wine_info['vineyard']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
            else if($sub_field['name'] == 'bottle_shot' && !$wine_info['bottle_shots']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
            else if($sub_field['name'] == 'label' && !$wine_info['wine_labels']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
            else if($sub_field['name'] == 'tech_sheet' && !$wine_info['tech_sheets']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
            else if($sub_field['name'] == 'shelf_talker' && !$wine_info['shelf_talkers']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
            else if($sub_field['name'] == 'video' && !$wine_info['videos']['enabled']) {
                unset($field['sub_fields'][$key]);
            }
        }
        
        return $field;
    }

	/**
     * @method load_wine_name
     */	 
    static public function load_wine_name($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['wine']['label'];
        return $field;
    }

	/**
     * @method load_wine_vineyard
     */	 
    static public function load_wine_vineyard($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['vineyard']['label'];
        return $field;
    }

	/**
     * @method load_wine_bottle_shots
     */	 
    static public function load_wine_bottle_shots($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['bottle_shots']['label'];
        return $field;
    }

	/**
     * @method load_wine_labels
     */	 
    static public function load_wine_labels($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['wine_labels']['label'];
        return $field;
    }

	/**
     * @method load_wine_tech_sheets
     */	 
    static public function load_wine_tech_sheets($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['tech_sheets']['label'];
        return $field;
    }

	/**
     * @method load_wine_shelf_talkers
     */	 
    static public function load_wine_shelf_talkers($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['shelf_talkers']['label'];
        return $field;
    }

	/**
     * @method load_wine_videos
     */	 
    static public function load_wine_videos($field) 
    {
        $wine_info = TMSettings::get('wine_info');
        $field['label'] = $wine_info['videos']['label'];
        return $field;
    }
}