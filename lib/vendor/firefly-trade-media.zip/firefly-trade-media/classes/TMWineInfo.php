<?php

/**
 * @class TMWineInfo
 */
final class TMWineInfo {

	/**
     * @method get_html
     */	 
    static public function get_html($post_id = null) 
    {
        $columns = TMSettings::get('wine_info');
        $groups  = get_field('wine_info', $post_id);
        
        foreach($groups as $group) {

            include TM_PLUGIN_DIR . 'includes/wine-info-group.php';
        }
    }
}