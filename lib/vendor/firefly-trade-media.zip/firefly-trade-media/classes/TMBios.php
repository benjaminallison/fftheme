<?php

/**
 * @class TMBios
 */
final class TMBios {

	/**
     * @method get_html
     */	 
    static public function get_html($post_id = null) 
    {
        $bios = get_field('bios', $post_id);
        
        echo '<div class="tm-thumbs tm-clearfix">';
        
        foreach($bios as $bio) {
        
            $bio_id = uniqid('tm-bio-');
        
            include TM_PLUGIN_DIR . 'includes/bio-thumb.php';
        }
        
        echo '</div>';
    }
}