<?php

/**
 * @class TMGallery
 */
final class TMGallery {

	/**
     * @method get_html
     */	 
    static public function get_html($post_id = null) 
    {
        $groups = get_field('gallery', $post_id);
        
        foreach($groups as $group) {
        
            include TM_PLUGIN_DIR . 'includes/gallery-group.php';
        }
    }

	/**
     * @method get_photos_html
     */	 
    static public function get_photos_html($group) 
    {
        foreach($group['photos'] as $photo) {
            
            if(empty($photo['photo'])) {
                continue;
            }
            
            $urls  = self::get_photo_download_urls($photo);
            $photo = $photo['photo'];
            
            include TM_PLUGIN_DIR . 'includes/gallery-photo.php';
        }
    }

	/**
     * @method get_videos_html
     */	 
    static public function get_videos_html($group) 
    {
        foreach($group['videos'] as $video) {
        
            include TM_PLUGIN_DIR . 'includes/gallery-video.php';
        }
    }

	/**
     * @method get_photo_download_urls
     */	 
    static public function get_photo_download_urls($data) 
    {
        $urls = array();
            
        if(!empty($data['photo'])) {
            $urls = TMCore::get_photo_download_urls($data['photo']);
        }
        if(!empty($data['file'])) {
            $urls['file'] = TMCore::get_download_url($data['file']['url'], get_post_mime_type($data['file']['ID']));
        }
        
        return $urls;
    }
}