<?php

/**
 * @class TMSettings
 */
final class TMSettings {

	/**
     * @method get
     */	 
    static public function get($key) 
    {
        $settings = self::get_all();
        
        return isset($settings[$key]) ? $settings[$key] : null;
    }

	/**
     * @method get_settings
     */	 
    static public function get_all() 
    {
        $settings = get_option('tm_settings', array());
        
        $defaults = array(
            'index_title'   => "Trade &amp; Media",
            'index_type'  => 'brand',
            'product_type'  => 'wine',
            'multi_brand'   => 1,
            'hide_acf_ui'   => 0,
            'slug'          => TM_POST_TYPE,
            'search_form'   => 1,
            'wine_info'     => array(
                'wine'          => array(
                    'label'         => __('Wine', 'firefly'),
                    'enabled'       => '1'
                ),
                'vineyard'      => array(
                    'label'         => __('Vineyard', 'firefly'),
                    'enabled'       => '1'
                ),
                'bottle_shots'  => array(
                    'label'         => __('Bottle Shots', 'firefly'),
                    'enabled'       => '1'
                ),
                'wine_labels'   => array(
                    'label'         => __('Wine Labels', 'firefly'),
                    'enabled'       => '1'
                ),
                'tech_sheets'   => array(
                    'label'         => __('Tech Sheets', 'firefly'),
                    'enabled'       => '1'
                ),
                'shelf_talkers' => array(
                    'label'         => __('Shelf Talkers', 'firefly'),
                    'enabled'       => '1'
                ),
                'videos'        => array(
                    'label'         => __('Videos', 'firefly'),
                    'enabled'       => '1'
                )
            )
        );
        
        return array_merge($defaults, $settings);
    }

	/**
     * @method admin_menu
     */	 
    static public function admin_menu() 
    {
        $name = __('Trade &amp; Media', 'firefly');
        
        add_submenu_page('options-general.php', $name, $name, 'delete_plugins', 'tm-settings', 'TMSettings::render');
    }

	/**
     * @method render
     */	 
    static public function render() 
    {
        $settings = self::get_all();
        
        include TM_PLUGIN_DIR . 'includes/settings.php';
    }

	/**
     * @method save
     */	 
    static public function save() 
    {
        // Only save on the settings page.
        if(!isset($_REQUEST['page']) || $_REQUEST['page'] != 'tm-settings') {
            return;
        }
        
	    // Only admins can save settings.
	    else if(!current_user_can('delete_plugins')) {
    	    return;
	    }
	    
		// Invalid nonce.
        else if(!isset($_POST['tm-settings-nonce']) || !wp_verify_nonce($_POST['tm-settings-nonce'], 'tm-settings')) {
            return;
        }
        
        // Make sure we have page title.
        if(empty($_POST['tm_settings']['index_title'])) {
            $_POST['tm_settings']['index_title'] = "Trade &amp; Media";

        }
        // Make sure we have a slug.
        if(empty($_POST['tm_settings']['slug'])) {
            $_POST['tm_settings']['slug'] = TM_POST_TYPE;
        }
        
        // Update the settings.
        update_option('tm_settings', $_POST['tm_settings']);
    }

	/**
     * @method flush_rewrite_rules
     */	 
    static public function flush_rewrite_rules() 
    {
        if(isset($_COOKIE['TM_ACTIVATING'])) {
            setcookie('TM_ACTIVATING', '', time()-3600);
            flush_rewrite_rules(false);
        }
        if(isset($_POST['tm-settings-nonce']) && wp_verify_nonce($_POST['tm-settings-nonce'], 'tm-settings')) {
            flush_rewrite_rules(false);
        }
    }
}